//
//  ViewController.swift
//  FinalApp
//
//  Created by Daksh on 02/02/23.
//

import UIKit

class ViewController: BackgroundGradient {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

