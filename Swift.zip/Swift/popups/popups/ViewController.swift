//
//  ViewController.swift
//  popups
//
//  Created by Daksh on 29/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

   
    @IBAction func buttn(_ sender: Any) {
        
    }
   
    
}

