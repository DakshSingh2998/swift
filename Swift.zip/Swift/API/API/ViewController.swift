//
//  ViewController.swift
//  API
//
//  Created by Daksh on 31/01/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return customerModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        cell.textLabel?.text = customerModel[indexPath.row].title
        print(customerModel[indexPath.row].title)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var svc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ViewController2") as? ViewController2
        
        svc?.customerData = customerModel[indexPath.row]
        navigationController?.pushViewController(svc!, animated: true)
        
    }
    
    @IBOutlet weak var tableView: UITableView!
    var customerModel:[CustomerModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }


    @IBAction func loadButtonAction(_ sender: Any) {
        NetworkManager.shared.getApi(){
            data in
            guard let data = data as? [String: Any] else {return}
            guard let values = data["results"] as? [[String: Any]] else {return}
            print(values)
            self.customerModel = values.map{CustomerModel(data: $0)}
            print(values)
            
            DispatchQueue.main.async { [weak self] in
                self!.tableView.reloadData()
            }
            
        }
        
    }
}

