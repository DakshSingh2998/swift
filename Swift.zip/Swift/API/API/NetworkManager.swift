//
//  NetworkManager.swift
//  API
//
//  Created by Daksh on 01/02/23.
//

import Foundation
class NetworkManager{
    static var shared = NetworkManager()
    
    var url = "https://api.themoviedb.org/3/movie/popular?api_key=314778b919b218a848acfcee10a6c785"
    
    func getApi(completition: ((Any)->())?){
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let session = URLSession.shared
        session.dataTask(with: request){
            data, response, err in
            if let err = err{
                print(err.localizedDescription)
                return
            }
            guard let jsonData = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) else{
                print("SERL ERR")
                return
            }
            print(jsonData)
            completition?(jsonData)
        }.resume()
        
        
    }
}
