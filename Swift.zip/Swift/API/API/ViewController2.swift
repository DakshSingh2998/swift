//
//  ViewController2.swift
//  API
//
//  Created by Daksh on 01/02/23.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var regionLabel: UILabel!
    
    var customerData:CustomerModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let toSet = customerData?.genre_ids.randomElement() else{
            return
        }
        regionLabel.text = "\(toSet)"
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
