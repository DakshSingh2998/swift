//
//  CustomClass.swift
//  project2
//
//  Created by Daksh on 25/01/23.
//

import Foundation
import UIKit
class CustomClass: UISlider{
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        print("kk")
        self.tintColor = .purple
//        self.clipsToBounds = true
        self.maximumTrackTintColor = .systemPink
        
        }
    
}
