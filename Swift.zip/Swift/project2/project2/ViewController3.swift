//
//  ViewController3.swift
//  project2
//
//  Created by Daksh on 23/01/23.
//

import UIKit
protocol protocol1{
    func sendData(rcvData: Bool)
}
class ViewController3: UIViewController  {

    @IBOutlet weak var obj2: UILabel!
    @IBOutlet weak var swtch: UISwitch!
    @IBOutlet weak var obj1: UILabel!
    var data = ""
    var data2 = 0
    var delegate: protocol1? = nil
    
    @IBOutlet weak var slider1: CustomClass!
    
    @IBAction func bttn(_ sender: Any) {
        
    }
    @IBAction func temp1(_ sender: Any) {
        
    }
    override func viewDidDisappear(_ animated: Bool) {
        delegate?.sendData(rcvData: swtch.isOn)
    }
    
    func overrideviewDidLoad() {
        super.viewDidLoad()
        print(data)
        }
    override func viewWillAppear(_ animated: Bool) {
        swtch.setOn(false, animated: true)
    
        obj1.text = data
        
        obj2.text = "d" + String(data2)
        
        
        
    }
    
    
    @IBAction func slider1actn(_ sender: Any) {
    }
    
    @IBAction func tuo(_ sender: Any) {
        
    }
    
    @IBAction func tui(_ sender: Any) {
        if(slider1.value > 0.10 && slider1.value<=0.30){
            slider1.setValue(0.20, animated: true)
        }
        if(slider1.value >  0.30 && slider1.value<0.50){
            slider1.setValue(0.40, animated: true)
        }
        if(slider1.value > 0.50 && slider1.value<0.70){
            slider1.setValue(0.60, animated: true)
        }
        if(slider1.value > 0.70 && slider1.value<0.90){
            slider1.setValue(0.80, animated: true)
        }
//        else if (slider1.value >= 0.90, {
//            slider1.setValue(0.100, animated: true))
//        }
//        else{
//            slider1.setValue(1.0, animated: true)
//        }
                 }
    
    @IBAction func slider1val(_ sender: Any) {
        
                
    }
    // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


