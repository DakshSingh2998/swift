//
//  ViewController2.swift
//  project2
//
//  Created by Daksh on 23/01/23.
//

import UIKit

class ViewController2: UIViewController,UITableViewDataSource, UITableViewDelegate, protocol1 {
    
    @IBOutlet weak var tbv: UITableView!
    var lstclk = -1
    var temprcv = false
    func sendData(rcvData: Bool) {
        print(rcvData)
        temprcv = rcvData
        //print(lstclk)
        tbv.reloadData()
    }
    
    //if ((temprcv == true) && lstclk ==  (IndexPath.row)){
       // swtch.isOn
    //}
    var arr = ["palak","daksh","ashish"]
    var  arr2 = [1,2,3]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? TableViewCell
        cell?.lbl1.text = arr[indexPath.row]
        cell?.lbl2.text = String(arr2[indexPath.row])
        print(lstclk)
        if (lstclk == indexPath.row){
         cell?.view1.backgroundColor = .red
        }
        else{
            cell?.view1.backgroundColor = .white
        }
        
        
        return cell!
        }
    

    
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var cn = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ViewController3") as? ViewController3
        lstclk = indexPath.row
        cn?.delegate = self
        cn?.data = arr[indexPath.row]
        cn?.data2 = arr2[indexPath.row]
        
//        cell?.lbl1.text = arr[indexPath.row]
//        cell?.lbl2.text = String(arr2[indexPath.row])
        
        navigationController?.pushViewController(cn!, animated: true)
        
        
        func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
