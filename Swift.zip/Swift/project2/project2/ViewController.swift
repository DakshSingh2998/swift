//
//  ViewController.swift
//  project2
//
//  Created by Daksh on 23/01/23.
//

import UIKit

class ViewController: UIViewController{
    @IBOutlet weak var view1: UIView!
    var myLabel = UILabel()
    
    
    
    @IBOutlet weak var tf1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after T
        
        view1.addSubview(myLabel)
//        myLabel.relo
        myLabel.backgroundColor = .red
        
        myLabel.text = "Hello World!!"
    }
    
    @IBAction func tfa1(_ sender: Any) {
        print(tf1.text!)
    }
    
    
    
    @IBAction func ButtonObj(_ sender: Any) {
        print(tf1.text)
        var bn = UIStoryboard(name: "Main", bundle: Bundle.main
        ).instantiateViewController(withIdentifier: "ViewController2") as? ViewController2
        navigationController?.pushViewController(bn!, animated: true)
        
        
    }
    
}
